import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { 
  Wallet, 
  Plus, 
  ArrowUp, 
  ArrowDown, 
  Bell, 
  User,
  TrendingUp,
  TrendingDown,
  DollarSign 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertTransactionSchema } from "@shared/schema";
import type { Transaction, InsertTransaction } from "@shared/schema";

type FilterType = "all" | "income" | "expense";

interface Summary {
  totalIncome: number;
  totalExpenses: number;
  balance: number;
}

export default function Home() {
  const [selectedType, setSelectedType] = useState<"income" | "expense">("expense");
  const [filter, setFilter] = useState<FilterType>("all");
  const { toast } = useToast();

  const form = useForm<InsertTransaction>({
    resolver: zodResolver(insertTransactionSchema),
    defaultValues: {
      type: "expense",
      amount: 0,
      description: "",
      category: "",
    },
  });

  // Fetch transactions
  const { data: transactions = [], isLoading: transactionsLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions", filter !== "all" ? `?type=${filter}` : ""],
  });

  // Fetch summary
  const { data: summary, isLoading: summaryLoading } = useQuery<Summary>({
    queryKey: ["/api/summary"],
  });

  // Create transaction mutation
  const createTransactionMutation = useMutation({
    mutationFn: async (data: InsertTransaction) => {
      const response = await apiRequest("POST", "/api/transactions", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      form.reset();
      toast({
        title: "Success",
        description: "Transaction added successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add transaction",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertTransaction) => {
    createTransactionMutation.mutate({ ...data, type: selectedType });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
    }).format(amount);
  };

  const formatDate = (date: string | Date) => {
    const dateObj = new Date(date);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (dateObj.toDateString() === today.toDateString()) {
      return `Today, ${format(dateObj, "h:mm a")}`;
    } else if (dateObj.toDateString() === yesterday.toDateString()) {
      return `Yesterday, ${format(dateObj, "h:mm a")}`;
    } else {
      return format(dateObj, "MMMM d, yyyy");
    }
  };

  const getCategoryDisplayName = (category: string) => {
    const categoryMap: Record<string, string> = {
      food: "Food & Dining",
      transport: "Transportation",
      shopping: "Shopping",
      bills: "Bills & Utilities",
      entertainment: "Entertainment",
      health: "Health & Medical",
      salary: "Salary",
      freelance: "Freelance",
      other: "Other",
    };
    return categoryMap[category] || category;
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-neutral-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Wallet className="text-white" size={20} />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-neutral-800">Expense Tracker</h1>
                <p className="text-sm text-neutral-500">Personal Finance Manager</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 text-neutral-500 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 transition-colors">
                <Bell size={18} />
              </button>
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <User className="text-white" size={16} />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Add Transaction Form */}
          <div className="lg:col-span-1">
            <Card className="shadow-sm border-neutral-200">
              <CardHeader className="pb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Plus className="text-primary" size={16} />
                  </div>
                  <CardTitle className="text-lg">Add Transaction</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {/* Transaction Type */}
                  <div>
                    <Label className="text-sm font-medium text-neutral-700 mb-3 block">
                      Transaction Type
                    </Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Button
                        type="button"
                        variant={selectedType === "income" ? "success" : "outline"}
                        className={`justify-center px-4 py-3 ${
                          selectedType === "income"
                            ? "border-success/20 bg-success/5 text-success hover:border-success/40"
                            : "border-neutral-200 bg-neutral-50 text-neutral-600 hover:bg-neutral-100"
                        }`}
                        onClick={() => setSelectedType("income")}
                      >
                        <ArrowUp className="mr-2" size={16} />
                        Income
                      </Button>
                      <Button
                        type="button"
                        variant={selectedType === "expense" ? "danger" : "outline"}
                        className={`justify-center px-4 py-3 ${
                          selectedType === "expense"
                            ? "border-danger/20 bg-danger/5 text-danger hover:border-danger/40"
                            : "border-neutral-200 bg-neutral-50 text-neutral-600 hover:bg-neutral-100"
                        }`}
                        onClick={() => setSelectedType("expense")}
                      >
                        <ArrowDown className="mr-2" size={16} />
                        Expense
                      </Button>
                    </div>
                  </div>

                  {/* Amount */}
                  <div>
                    <Label htmlFor="amount" className="text-sm font-medium text-neutral-700 mb-2 block">
                      Amount
                    </Label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <span className="text-neutral-500 text-sm font-medium">₹</span>
                      </div>
                      <Input
                        id="amount"
                        type="number"
                        step="0.01"
                        min="0"
                        placeholder="0.00"
                        className="pl-7 py-3 border-neutral-200 focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        {...form.register("amount", { valueAsNumber: true })}
                      />
                    </div>
                    {form.formState.errors.amount && (
                      <p className="mt-1 text-sm text-danger">
                        {form.formState.errors.amount.message}
                      </p>
                    )}
                  </div>

                  {/* Description */}
                  <div>
                    <Label htmlFor="description" className="text-sm font-medium text-neutral-700 mb-2 block">
                      Description
                    </Label>
                    <Input
                      id="description"
                      placeholder="What was this for?"
                      className="py-3 border-neutral-200 focus:ring-2 focus:ring-primary/20 focus:border-primary"
                      {...form.register("description")}
                    />
                    {form.formState.errors.description && (
                      <p className="mt-1 text-sm text-danger">
                        {form.formState.errors.description.message}
                      </p>
                    )}
                  </div>

                  {/* Category */}
                  <div>
                    <Label htmlFor="category" className="text-sm font-medium text-neutral-700 mb-2 block">
                      Category
                    </Label>
                    <Select
                      value={form.watch("category")}
                      onValueChange={(value) => form.setValue("category", value)}
                    >
                      <SelectTrigger className="py-3 border-neutral-200 focus:ring-2 focus:ring-primary/20 focus:border-primary">
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="food">Food & Dining</SelectItem>
                        <SelectItem value="transport">Transportation</SelectItem>
                        <SelectItem value="shopping">Shopping</SelectItem>
                        <SelectItem value="bills">Bills & Utilities</SelectItem>
                        <SelectItem value="entertainment">Entertainment</SelectItem>
                        <SelectItem value="health">Health & Medical</SelectItem>
                        <SelectItem value="salary">Salary</SelectItem>
                        <SelectItem value="freelance">Freelance</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    type="submit"
                    className="w-full py-3 font-medium"
                    disabled={createTransactionMutation.isPending}
                  >
                    <Plus className="mr-2" size={16} />
                    {createTransactionMutation.isPending ? "Adding..." : "Add Transaction"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* Financial Summary */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="shadow-sm border-neutral-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-neutral-500">Total Income</p>
                      <p className="text-2xl font-bold text-success mt-1">
                        {summaryLoading ? "..." : formatCurrency(summary?.totalIncome || 0)}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                      <TrendingUp className="text-success" size={20} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-sm border-neutral-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-neutral-500">Total Expenses</p>
                      <p className="text-2xl font-bold text-danger mt-1">
                        {summaryLoading ? "..." : formatCurrency(summary?.totalExpenses || 0)}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-danger/10 rounded-lg flex items-center justify-center">
                      <TrendingDown className="text-danger" size={20} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-sm border-neutral-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-neutral-500">Current Balance</p>
                      <p className="text-2xl font-bold text-neutral-800 mt-1">
                        {summaryLoading ? "..." : formatCurrency(summary?.balance || 0)}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Wallet className="text-primary" size={20} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Transaction Filters */}
            <Card className="shadow-sm border-neutral-200">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                  <h2 className="text-lg font-semibold text-neutral-800">Recent Transactions</h2>
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-2 bg-neutral-100 rounded-lg p-1">
                      <Button
                        variant={filter === "all" ? "default" : "ghost"}
                        size="sm"
                        className={`px-3 py-1.5 text-sm font-medium ${
                          filter === "all"
                            ? "bg-white text-neutral-800 shadow-sm"
                            : "text-neutral-500 hover:text-neutral-800"
                        }`}
                        onClick={() => setFilter("all")}
                      >
                        All
                      </Button>
                      <Button
                        variant={filter === "income" ? "default" : "ghost"}
                        size="sm"
                        className={`px-3 py-1.5 text-sm font-medium ${
                          filter === "income"
                            ? "bg-white text-neutral-800 shadow-sm"
                            : "text-neutral-500 hover:text-neutral-800"
                        }`}
                        onClick={() => setFilter("income")}
                      >
                        Income
                      </Button>
                      <Button
                        variant={filter === "expense" ? "default" : "ghost"}
                        size="sm"
                        className={`px-3 py-1.5 text-sm font-medium ${
                          filter === "expense"
                            ? "bg-white text-neutral-800 shadow-sm"
                            : "text-neutral-500 hover:text-neutral-800"
                        }`}
                        onClick={() => setFilter("expense")}
                      >
                        Expenses
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Transaction List */}
            <Card className="shadow-sm border-neutral-200">
              <CardHeader className="border-b border-neutral-200">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Transaction History</CardTitle>
                  <span className="text-sm text-neutral-500">
                    {transactions.length} transaction{transactions.length !== 1 ? "s" : ""}
                  </span>
                </div>
              </CardHeader>
              
              <div className="divide-y divide-neutral-200">
                {transactionsLoading ? (
                  <div className="p-6 text-center text-neutral-500">
                    Loading transactions...
                  </div>
                ) : transactions.length === 0 ? (
                  <div className="p-6 text-center text-neutral-500">
                    No transactions found. Add your first transaction above!
                  </div>
                ) : (
                  transactions.map((transaction) => (
                    <div
                      key={transaction.id}
                      className="p-6 hover:bg-neutral-50 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div
                            className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                              transaction.type === "income"
                                ? "bg-success/10"
                                : "bg-danger/10"
                            }`}
                          >
                            {transaction.type === "income" ? (
                              <ArrowUp className="text-success" size={16} />
                            ) : (
                              <ArrowDown className="text-danger" size={16} />
                            )}
                          </div>
                          <div>
                            <h4 className="font-medium text-neutral-800">
                              {transaction.description}
                            </h4>
                            <p className="text-sm text-neutral-500">
                              {transaction.category ? getCategoryDisplayName(transaction.category) : "Other"} • {formatDate(transaction.createdAt)}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p
                            className={`font-semibold ${
                              transaction.type === "income"
                                ? "text-success"
                                : "text-danger"
                            }`}
                          >
                            {transaction.type === "income" ? "+" : "-"}
                            {formatCurrency(transaction.amount)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </Card>
          </div>
        </div>
      </main>

      {/* Mobile Floating Action Button */}
      <div className="fixed bottom-6 right-6 lg:hidden">
        <Button
          className="w-14 h-14 bg-primary text-white rounded-full shadow-lg hover:bg-primary/90"
          size="icon"
        >
          <Plus size={20} />
        </Button>
      </div>
    </div>
  );
}
