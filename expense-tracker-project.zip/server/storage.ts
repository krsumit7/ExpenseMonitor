import { transactions, type Transaction, type InsertTransaction } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  // Transaction methods
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getAllTransactions(): Promise<Transaction[]>;
  getTransactionsByType(type: "income" | "expense"): Promise<Transaction[]>;
  deleteTransaction(id: string): Promise<boolean>;
  
  // Summary methods
  getTotalByType(type: "income" | "expense"): Promise<number>;
  getBalance(): Promise<number>;
}

export class MemStorage implements IStorage {
  private transactions: Map<string, Transaction>;

  constructor() {
    this.transactions = new Map();
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = randomUUID();
    const transaction: Transaction = {
      ...insertTransaction,
      id,
      category: insertTransaction.category || null,
      createdAt: new Date(),
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async getAllTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getTransactionsByType(type: "income" | "expense"): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter((transaction) => transaction.type === type)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async deleteTransaction(id: string): Promise<boolean> {
    return this.transactions.delete(id);
  }

  async getTotalByType(type: "income" | "expense"): Promise<number> {
    return Array.from(this.transactions.values())
      .filter((transaction) => transaction.type === type)
      .reduce((total, transaction) => total + transaction.amount, 0);
  }

  async getBalance(): Promise<number> {
    const income = await this.getTotalByType("income");
    const expenses = await this.getTotalByType("expense");
    return income - expenses;
  }
}

export class DatabaseStorage implements IStorage {
  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values(insertTransaction)
      .returning();
    return transaction;
  }

  async getAllTransactions(): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .orderBy(transactions.createdAt);
  }

  async getTransactionsByType(type: "income" | "expense"): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.type, type))
      .orderBy(transactions.createdAt);
  }

  async deleteTransaction(id: string): Promise<boolean> {
    const result = await db
      .delete(transactions)
      .where(eq(transactions.id, id));
    return (result.rowCount || 0) > 0;
  }

  async getTotalByType(type: "income" | "expense"): Promise<number> {
    const result = await db
      .select()
      .from(transactions)
      .where(eq(transactions.type, type));
    return result.reduce((total, transaction) => total + transaction.amount, 0);
  }

  async getBalance(): Promise<number> {
    const income = await this.getTotalByType("income");
    const expenses = await this.getTotalByType("expense");
    return income - expenses;
  }
}

export const storage = new DatabaseStorage();
